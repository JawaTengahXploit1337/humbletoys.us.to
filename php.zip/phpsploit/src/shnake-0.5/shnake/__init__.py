_version__ = "0.5"
__author__ = "nil0x42 <http://goo.gl/kb2wf>"

from .lexer import Lexer, lex
from .parser import Parser, parse
from .shell import Shell
