"""Miscelaneous decorators.

Collection of decorators used by the phpsploit framework's core

"""
