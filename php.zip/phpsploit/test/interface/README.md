# Functional Tests: interface

Test related to command-line user interface behavior
and general user experience.
